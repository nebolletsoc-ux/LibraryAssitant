import csv
import os
from uuid import uuid4

from flask import Flask, jsonify, render_template, request, session

from library.availability import search_availability
from library.importer import parse_books_from_text
from library.isbn import find_isbn

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = os.path.join(os.getcwd(), "uploads")
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev-secret")
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)


def get_parsed_books():
    source_path = session.get("books_source")
    if source_path and os.path.exists(source_path):
        with open(source_path, newline="", encoding="utf-8") as file:
            text = file.read()
        return parse_books_from_text(text, os.path.basename(source_path))

    with open("books.csv", newline="", encoding="utf-8") as file:
        return parse_books_from_text(file.read(), "books.csv")


def build_book_rows(books_data, limit=None):
    rows = []
    items = books_data[:limit] if limit is not None else books_data
    for item in items:
        title = (item.get("title") or "").strip()
        author = (item.get("author") or "").strip()
        availability = []

        if title:
            try:
                availability = search_availability(title, author, timeout=12)
            except Exception:
                availability = []

        isbn = item.get("isbn") or None
        if not isbn and title:
            try:
                isbn = find_isbn(title, author)
            except Exception:
                isbn = None

        rows.append({
            "title": title,
            "author": author,
            "isbn": isbn,
            "availability": availability,
        })

    return rows


@app.route("/", methods=["GET", "POST"])
def home():
    books = []

    if request.method == "POST":
        uploaded_file = request.files.get("books_file")
        if uploaded_file and uploaded_file.filename:
            text = uploaded_file.read().decode("utf-8", errors="ignore")
            parsed_books = parse_books_from_text(text, uploaded_file.filename)
            source_path = os.path.join(app.config["UPLOAD_FOLDER"], f"{uuid4().hex}.csv")
            with open(source_path, "w", encoding="utf-8") as file:
                file.write(text)
            session["books_source"] = source_path
            books = build_book_rows(parsed_books, limit=20)
            return render_template(
                "index.html",
                books=books,
                uploaded=True,
                total_books=len(parsed_books),
            )

    parsed_books = get_parsed_books()
    books = build_book_rows(parsed_books, limit=20)
    return render_template("index.html", books=books, uploaded=False, total_books=len(parsed_books))


@app.route("/load-more")
def load_more():
    offset = max(0, int(request.args.get("offset", 0)))
    limit = max(1, int(request.args.get("limit", 20)))
    parsed_books = get_parsed_books()
    batch = parsed_books[offset:offset + limit]
    rows = build_book_rows(batch)
    html = render_template("book_rows.html", books=rows)
    return jsonify({
        "html": html,
        "has_more": offset + len(rows) < len(parsed_books),
        "next_offset": offset + len(rows),
    })


if __name__ == "__main__":
    app.run(debug=False, host="127.0.0.1", port=int(os.environ.get("PORT", "5000")))