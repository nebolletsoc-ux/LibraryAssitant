import requests

def find_isbn(title, author):

    search_url = "https://openlibrary.org/search.json"

    params = {
        "title": title,
        "author": author,
        "limit": 1
    }

    response = requests.get(search_url, params=params)

    docs = response.json().get("docs", [])

    if not docs:
        return None

    work_key = docs[0]["key"]

    editions = requests.get(
        f"https://openlibrary.org{work_key}/editions.json"
    ).json()

    for edition in editions.get("entries", []):

        if "isbn_13" in edition:
            return edition["isbn_13"][0]

        if "isbn_10" in edition:
            return edition["isbn_10"][0]

    return None