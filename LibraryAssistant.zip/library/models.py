from dataclasses import dataclass, field
import uuid


@dataclass
class Book:

    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    title: str = ""
    author: str = ""

    isbn: str | None = None

    results: list = field(default_factory=list)