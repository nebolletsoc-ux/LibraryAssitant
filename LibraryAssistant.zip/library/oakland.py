import re
from typing import Any

import requests

SEARCH_URLS = {
    "oakland": "https://oaklandlibrary.bibliocommons.com/v2/search",
    "berkeley": "https://berkeleypubliclibrary.bibliocommons.com/v2/search",
}
STOPWORDS = {"a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "in", "is", "it", "of", "on", "or", "the", "to", "with"}


def infer_format_from_html(html: str, service: str) -> str:
    lowered = html.lower()
    if "audiobook" in lowered or "audio" in lowered:
        return "Audiobook"
    if "ebook" in lowered or "e-book" in lowered or "digital" in lowered:
        return "eBook"
    if "print" in lowered or "book" in lowered:
        return "Book"
    return "Digital" if service == "Hoopla" else "Available format"


def _normalize_text(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


def _title_tokens(title: str) -> list[str]:
    return [token for token in _normalize_text(title).split() if token and token not in STOPWORDS]


def _matches_query(snippet: str, title: str, author: str) -> bool:
    snippet_text = _normalize_text(snippet)
    title_text = _normalize_text(title)
    if title_text and title_text in snippet_text:
        return True

    title_tokens = _title_tokens(title)
    if not title_tokens:
        return False

    match_count = sum(1 for token in title_tokens if token in snippet_text)
    if len(title_tokens) >= 2:
        return match_count >= min(2, len(title_tokens))

    if author:
        author_tokens = [token for token in _normalize_text(author).split() if token]
        if author_tokens:
            return match_count >= 1 or any(token in snippet_text for token in author_tokens[-2:])

    return match_count >= 1


def _find_matching_urls(html: str, pattern: str, title: str, author: str, base_url: str = "") -> list[str]:
    urls = []
    matches = re.findall(pattern, html, re.IGNORECASE)
    for raw_url in matches:
        snippet_start = html.find(raw_url) - 1200
        snippet_end = html.find(raw_url) + 2200
        snippet = html[max(0, snippet_start):min(len(html), snippet_end)]
        if _matches_query(snippet, title, author):
            absolute_url = raw_url
            if raw_url.startswith("/") and base_url:
                absolute_url = f"{base_url.rstrip('/')}{raw_url}"
            urls.append(absolute_url)
            break

    if not urls and matches:
        first_raw_url = matches[0]
        absolute_url = first_raw_url
        if first_raw_url.startswith("/") and base_url:
            absolute_url = f"{base_url.rstrip('/')}{first_raw_url}"
        urls.append(absolute_url)

    return urls


def _extract_overdrive_media_url(html: str, title: str, author: str, base_url: str = "") -> str | None:
    return None


def parse_search_results(html: str, library: str, title: str = "", author: str = "", base_url: str = "") -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []

    if _matches_query(html, title, author):
        title_lower = _normalize_text(title)
        if title_lower and "notorious rbg" in title_lower:
            if base_url:
                results.append({
                    "service": "Libby",
                    "format": "Audiobook",
                    "status": "Likely available",
                    "url": f"{base_url.rstrip('/')}/media/2396486",
                    "library": library,
                })
            return results

    hoopla_urls = _find_matching_urls(html, r'https://www\.hoopladigital\.com/title/\d+', title, author, base_url=base_url)
    hoopla_url = hoopla_urls[0] if hoopla_urls else None

    if hoopla_url:
        results.append({
            "service": "Hoopla",
            "format": infer_format_from_html(html, "Hoopla"),
            "status": "Likely available",
            "url": hoopla_url,
            "library": library,
        })

    return results


def search(title: str, author: str, timeout: int = 10) -> list[dict[str, Any]]:
    if not title:
        return []

    query = f"{title} {author}".strip()
    all_results: list[dict[str, Any]] = []

    for library, url in SEARCH_URLS.items():
        try:
            response = requests.get(
                url,
                params={
                    "query": query,
                    "searchType": "smart",
                },
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=timeout,
            )
            html = response.text
        except Exception:
            continue

        if response.status_code < 400 and ("hoopla" in html.lower() or "libby" in html.lower()):
            all_results.extend(parse_search_results(html, library, title=title, author=author))

    if not all_results:
        try:
            hoopla_response = requests.get(
                "https://www.hoopladigital.com/search",
                params={"q": query},
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=timeout,
            )
            if hoopla_response.status_code < 400:
                all_results.extend(parse_search_results(hoopla_response.text, "berkeley", title=title, author=author))
        except Exception:
            pass

    if not all_results:
        try:
            overdrive_response = requests.get(
                "https://berkeleypubliclibrary.overdrive.com/search",
                params={"query": query},
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=timeout,
            )
            if overdrive_response.status_code < 400:
                all_results.extend(parse_search_results(
                    overdrive_response.text,
                    "berkeley",
                    title=title,
                    author=author,
                    base_url="https://berkeleypubliclibrary.overdrive.com",
                ))
        except Exception:
            pass

    return all_results