STATUS = {

    book.id: {

        "state": "checking",

        "progress": 42,

        "message": "Checking Oakland"

    }

}